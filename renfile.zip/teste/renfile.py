import os
from datetime import datetime, timezone

def main():
    i = 1
    path_source = "C:/temp/teste/"
    path_dest = "C:/temp/teste/dest/"
    for filename in os.listdir(path_source):       
        my_source = path_source + filename
        if filename.startswith("ARQ") and filename.endswith(".RET"):
            conta = loadline(filename)
            data_e_hora_atuais = datetime.now()
            data_e_hora_em_texto = data_e_hora_atuais.strftime("%d%m%Y%H%M%S%f")
            my_dest = path_dest + "ARQ" + conta + data_e_hora_em_texto + str(i) + ".RET"
            if os.path.exists(my_dest):
                i += 1
                my_dest = path_dest + "ARQ" + conta + data_e_hora_em_texto + str(i) + ".RET"
            '''print("Arq: " + filename + " Conta : " + conta)'''
            os.rename(my_source, my_dest)

def loadline(filename):
    arquivo = open(filename)
    conta = arquivo.readline()
    return conta[24:29]

if __name__ == "__main__" :
    main()

